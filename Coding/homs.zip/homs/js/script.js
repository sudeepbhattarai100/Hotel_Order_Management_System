$(document).ready(function () {

    //for notification
    $(".notification").slideDown(300);

    $(".notification").delay(4000).fadeOut("slow");


    //logout click

    $("#log_out").click(function () {
        if (confirm("Do you want to logout?")) {
            $.ajax({
                url: '../Controller/LoginController.php',
                type: 'post',
                data: {logout: true},
                success: function () {
                    location.reload();
                    
                }
            })
        }
    });


    $("#category").change(function(){
        var id = $(this).val();
        //alert(id);
        $.ajax({
            url : '../Controller/OrderController.php',
            type : 'post',
            data : {category_id: id},
            dataType: "json",
            success: function (data){
                console.log(data);
                $('#food').empty();

                if(data.length == 0 ){
                    $('#food').append("<option value='0'>No Food Found</option>");
                    $('#food').prop('disabled', 'disabled');
                }else{
                    $('#food').removeAttr("disabled");
                    $('#food').append("<option value='0' selected>Select Food</option>");
                    $.each(data,function(key, value) {
                        $('#food').append("<option value='"+ value.food_id +"'>"+ value.food_name +"</option>");
                    });
                }
            }
        })
    });



});

