<?php
header("Location: view/index.php");