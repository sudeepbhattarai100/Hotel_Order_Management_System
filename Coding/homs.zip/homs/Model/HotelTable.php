<?php


class HotelTable
{
    public $table_id, $table_number;

    public static function AddNewTable(HotelTable $t){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("INSERT INTO hotel_table (table_number) VALUES (?)");
        $stmt->bind_param("i", $t->table_number);
        $result = $stmt->execute();
        $stmt->close();
        $conn->close();

        return $result;
    }

    public static function GetAllTable(){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("SELECT * FROM hotel_table ORDER BY table_id DESC");
        $stmt->execute();
        $data = $stmt->get_result();
        $tables = array();
        foreach ($data as $t){
            array_push($tables, $t);
        }

        $stmt->close();
        $conn->close();

        return $tables;
    }

    public static function DeleteTable($id){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("DELETE FROM hotel_table WHERE table_id = ?");
        $stmt->bind_param("i", $id);
        $result = $stmt->execute();

        $stmt->close();
        $conn->close();

        return $result;
    }
}