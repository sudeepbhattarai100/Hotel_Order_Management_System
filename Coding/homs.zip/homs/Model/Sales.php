<?php


class Sales
{
    public $sales_id, $table_id, $food_id, $quantity, $date;

    public static function AddSales(Sales $s){
        $conn = DbConnect::connection();
        $stmt =  $conn->prepare ("INSERT INTO sales(table_id, food_id, quantity, date) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiis",$s->table_id, $s->food_id, $s->quantity, $s->date);
        $result = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $result;
    }

    public static function GetAllSales(){
        $conn = DbConnect::connection();
        $stmt =  $conn->prepare ("SELECT * FROM sales sa JOIN food fo ON sa.food_id = fo.food_id JOIN category ca on fo.category_id = ca.category_id WHERE sa.date = '". date("Y-m-d") ."'");
        $stmt->execute();
        $data = $stmt->get_result();
        $sales = array();
        foreach ($data as $d){
            array_push($sales, $d);
        }

        $stmt->close();
        $conn->close();
        return $sales;
    }

    public static function FilterSales($category_id, $food_id, $start_date, $end_date){
        $conn = DbConnect::connection();
        $query = "SELECT * FROM sales sa JOIN food fo ON sa.food_id = fo.food_id JOIN category ca on fo.category_id = ca.category_id WHERE";


        if(!empty($category_id)){
            $query .= " ca.category_id = ".$category_id;
        }


        if(!empty($food_id)){
            $query .= " AND fo.food_id = ".$food_id;
        }

        if(empty($food_id) && empty($category_id)){
            $query .= " sa.date BETWEEN '".$start_date."' AND '".$end_date."'";
        }else{

            $query .= " AND sa.date BETWEEN '".$start_date."' AND '".$end_date."'";
        }

        $stmt =  $conn->prepare ($query);

        $stmt->execute();
        $data = $stmt->get_result();
        $sales = array();
        foreach ($data as $d){
            array_push($sales, $d);
        }

        $stmt->close();
        $conn->close();
        return $sales;
    }
}