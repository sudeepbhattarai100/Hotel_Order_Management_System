<?php

class User
{
    public $admin_id, $full_name, $email, $address, $phone, $image, $password, $role_id;

    public static function validateUser($email, $password){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("select count(user_id) as user_count from user where email = ? AND password = ?");
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $result = ($stmt->get_result())->fetch_assoc();

        if($result["user_count"] > 0){
            return true;
        }else{
            return false;
        }
    }

    public static function addUser(User $u){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("INSERT INTO user(email, password, role_id) VALUES(?,?,?)");
        $stmt->bind_param("sss",$u->email, $u->password, $u->role_id);
        $result = $stmt->execute();
        return $result;

    }

    public static function updateUser(User $a){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("UPDATE user SET full_name = ?, email = ?, address = ?, phone= ?, image = ?, password = ? WHERE user_id = ?");
        $stmt->bind_param("ssssssi",$a->full_name, $a->email, $a->address, $a->phone, $a->image, $a->password, $a->admin_id);
        $result = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $result;
    }

    public static function getAllUsers(){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("SELECT * FROM user u JOIN role r ON u.role_id = r.role_id");
        $stmt->execute();
        $data = $stmt->get_result();
        $users = array();
        foreach ($data as $d){
            array_push($users, $d);
        }
        $stmt->close();
        $conn->close();

        return $users;
    }


    public static function deleteUser($id){
        $conn = DbConnect::connection();
        $query = "delete from user where user_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();

        $row = $stmt->affected_rows;
        $stmt->close();
        $conn->close();

        if($row > 0){
            return true;
        }else{
            return false;
        }
    }

    public static function getUserById($id){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("SELECT * FROM user WHERE user_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $adminUser = $result->fetch_assoc();
        $stmt->close();
        $conn->close();
        return $adminUser;

    }

    public static function getUserByEmail($email){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("SELECT * FROM user WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $adminUser = $result->fetch_assoc();
        $stmt->close();
        $conn->close();
        return $adminUser;

    }

    public static function AddToRole($user_id, $role_id){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("UPDATE user SET role_id = ? WHERE user_id = ?");
        $stmt->bind_param("ii", $role_id, $user_id);
        $result = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $result;
    }

    public static function GetUserRole($id){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("SELECT * FROM user u JOIN role r ON u.role_id = r.role_id WHERE u.user_id = ?");
        $stmt->bind_param("i",$id);
        $result = $stmt->execute();
        $data = $stmt->get_result()->fetch_assoc();
        $role = $data["role"];
        $stmt->close();
        $conn->close();
        return $role;
    }
}