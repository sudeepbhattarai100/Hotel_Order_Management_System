<?php


class Food
{
    public $food_id, $food_name, $image, $price, $category_id;

    public static function GetAllFood(){
        $conn = DbConnect::connection();
        $stmt =  $conn->prepare ("SELECT * FROM food fo JOIN category ca ON fo.category_id = ca.category_id ORDER BY food_id DESC");
        $stmt->execute();

        $result = $stmt->get_result();
        $stmt->close();
        $conn->close();
        return $result;
    }

    public static function SearchFood($search){
        $conn = DbConnect::connection();
        $search = "'%".$search."%'";
        $stmt =  $conn->prepare ("SELECT * FROM food fd JOIN category ca ON fd.category_id = ca.category_id WHERE fd.food_name LIKE $search ORDER BY food_id DESC");

        $stmt->execute();

        $result = $stmt->get_result();
        $stmt->close();
        $conn->close();
        return $result;
    }

    public static function GetFoodById($id){
        $conn = DbConnect::connection();
        $stmt =  $conn->prepare ("SELECT * FROM food WHERE food_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();

        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $conn->close();
        return $result;
    }

//    public static function GetProductBelowMinQty(){
//        $product = self::GetAllProduct();
//        $updated_product = array();
//
//        foreach ($product as $p){
//            $available = Product::IndividualStockAvailable($p["product_id"]);
//            $danger_level = $p["minimum_qty"];
//
//            if($available <= $danger_level){
//                $p["color"] = "text-danger";
//                array_push($updated_product, $p);
//            }
//        }
//
//        return $updated_product;
//    }
//
//    public static function GetProduct20PercentAboveMinQty(){
//        $product = self::GetAllProduct();
//        $updated_product = array();
//        foreach ($product as $p){
//            $available = Product::IndividualStockAvailable($p["product_id"]);
//            $danger_level = $p["minimum_qty"];
//            $warning_level = $p["minimum_qty"] + (($p["minimum_qty"])*20/100);
//
//            if($available > $danger_level && $available <= $warning_level ){
//                $p["color"] = "text-warning";
//                array_push($updated_product, $p);
//            }
//        }
//
//        return $updated_product;
//    }
//
//    public static function GetMaxPurchasedProduct(){
//        $conn = databaseConnect::connection();
//        $stmt =  $conn->prepare ("select sum(pu.number_received) as total_purchases, p.product_id, p.product_name, p.image, p.manufacturer, c.category from product p left join category c on c.category_id = p.category_id left join purchases pu on pu.product_id = p.product_id group by p.product_id order by total_purchases desc limit 3");
//        $stmt->execute();
//
//        $result = $stmt->get_result();
//        $stmt->close();
//        $conn->close();
//        return $result;
//    }
//
//    public static function GetMaxSoldProduct(){
//        $conn = databaseConnect::connection();
//        $stmt =  $conn->prepare ("select sum(s.number_sold) as total_sales, p.product_id, p.product_name, p.image, p.manufacturer, c.category from product p left join category c on c.category_id = p.category_id left join sales s on s.product_id = p.product_id group by p.product_id order by total_sales desc limit 3");
//
//        $stmt->execute();
//        $result = $stmt->get_result();
//        $stmt->close();
//        $conn->close();
//        return $result;
//    }

    public static function GetFoodByCategoryId($id){
        $conn = DbConnect::connection();
        $stmt =  $conn->prepare ("SELECT * FROM food WHERE category_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();

        $result = $stmt->get_result();
        $foods = array();
        foreach ($result as $f){
            array_push($foods, $f);
        }

        $stmt->close();
        $conn->close();
        return $foods;
    }

    public static function AddFood(Food $f){
        $conn = DbConnect::connection();
        $stmt =  $conn->prepare ("INSERT INTO food(food_name, price, image, category_id) VALUES(?, ?, ?, ?)");
        $stmt->bind_param("sisi",$f->food_name, $f->price, $f->image, $f->category_id);
        $result = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $result;
    }

    public static function UpdateFood(Food $f){
        $conn = DbConnect::connection();
        $stmt =  $conn->prepare ("UPDATE food SET food_name = ?, price = ?, image = ?, category_id = ? WHERE food_id = ?");
        $stmt->bind_param("sisii",$f->food_name, $f->price, $f->image, $f->category_id, $f->food_id);
        $result = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $result;
    }

    public static function DeleteFood($id){
        $conn = DbConnect::connection();
        $stmt =  $conn->prepare ("DELETE FROM food WHERE food_id = ?");
        $stmt->bind_param("i",$id);
        $stmt->execute();
        $count = $stmt->affected_rows;
        $stmt->close();
        $conn->close();
        if($count > 0){
            return true;
        }else{
            return false;
        }
    }

//    public static function IndividualTotalPurchases($id){
//        $conn = databaseConnect::connection();
//        $stmt =  $conn->prepare ("SELECT SUM(number_received) as total_purchases FROM product pr LEFT JOIN purchases pu on pr.product_id = pu.product_id WHERE pr.product_id = ?");
//        $stmt->bind_param("i",$id);
//        $stmt->execute();
//        $result = $stmt->get_result()->fetch_assoc();
//        $total_purchases = $result["total_purchases"];
//        $stmt->close();
//        $conn->close();
//        return $total_purchases;
//    }
//
//
//    public static function IndividualTotalSales($id){
//        $conn = databaseConnect::connection();
//        $stmt =  $conn->prepare ("SELECT SUM(number_sold) as total_sales FROM product pr LEFT JOIN sales sa on pr.product_id = sa.product_id WHERE pr.product_id = ?");
//        $stmt->bind_param("i",$id);
//        $stmt->execute();
//        $result = $stmt->get_result()->fetch_assoc();
//        $total_sales = $result["total_sales"];
//        $stmt->close();
//        $conn->close();
//        return $total_sales;
//    }
//
//    public static function IndividualStockAvailable($id){
//        $total_purchases = self::IndividualTotalPurchases($id);
//        $total_sales = self::IndividualTotalSales($id);
//        $available = $total_purchases - $total_sales;
//        return $available;
//    }


}