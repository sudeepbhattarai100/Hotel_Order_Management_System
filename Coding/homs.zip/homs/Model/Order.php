<?php


class Order
{
    public $order_id, $table_id, $food_id, $quantity;

    public static function AddOrder(Order $o){
        $conn = DbConnect::connection();
        $stmt =  $conn->prepare ("INSERT INTO food_order(table_id, food_id, quantity) VALUES (?, ?, ?)");
        $stmt->bind_param("iii",$o->table_id, $o->food_id, $o->quantity);
        $result = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $result;
    }


    public static function GetTableDetailsOfActiveOrder(){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("SELECT ht.table_id, ht.table_number FROM food_order fo JOIN hotel_table ht ON fo.table_id = ht.table_id GROUP BY ht.table_number");
        $stmt->execute();
        $result = $stmt->get_result();
        $table = array();
        $stmt->close();
        $conn->close();
        foreach ($result as $r){
            array_push($table, $r);
        }

        return $table;
    }

    public static function GetOrderDetailsByTableId($table_id){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("SELECT * FROM food_order WHERE table_id = ?");
        $stmt->bind_param("i", $table_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        $conn->close();
        $order = array();
        foreach ($result as $r){
            array_push($order, $r);
        }
        return $order;
    }

    public static function DeleteOrderByTableId($table_id){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("DELETE FROM food_order WHERE table_id = ?");
        $stmt->bind_param("i", $table_id);
        $result = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $result;
    }

    public static function GetOrderByTable($table_id){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("SELECT * FROM food_order fo JOIN hotel_table ht ON fo.table_id = ht.table_id JOIN  food f ON fo.food_id = f.food_id JOIN category c on f.category_id = c.category_id WHERE ht.table_id = ?");
        $stmt->bind_param("i", $table_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        $conn->close();
        $OrderDetails = array();
        foreach ($result as $r){
            array_push($OrderDetails, $r);
        }

        return $OrderDetails;
    }

    public static function UpdateOrderStatus($order_id, $status){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("UPDATE food_order SET order_status = ? WHERE order_id = ?");
        $stmt->bind_param("si", $status, $order_id);
        $result = $stmt->execute();

        $stmt->close();
        $conn->close();

        return $result;
    }
}