<?php


class Role
{
    public $role_id, $role;

    public static  function AddRole(Role $r){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("INSERT INTO role (role) VALUES (?)");
        $stmt->bind_param("s", $r->role);
        $result = $stmt->execute();
        return $result;
    }

    public static function GetAllRoles(){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("SELECT * FROM role ORDER BY role_id DESC");
        $stmt->execute();
        $result = $stmt->get_result();
        $roles = array();
        foreach ($result as $r){
            array_push($roles, $r);
        }
        return $roles;
    }

    public static function GetRoleById($id){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("SELECT * FROM role WHERE role_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();

        return $result;
    }

    public static function GetUsersInRole($id){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("SELECT * FROM role r JOIN user u ON r.role_id = u.role_id WHERE r.role_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $users = array();

        foreach ($result as $r){
            array_push($users, $r);
        }
        return $users;
    }

    public static function GetUsersNotInRole($id){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("SELECT * FROM role r JOIN user u ON r.role_id = u.role_id WHERE r.role_id != ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $users = array();

        foreach ($result as $r){
            array_push($users, $r);
        }
        return $users;
    }

    public static function DeleteRole($id){
        $conn = DbConnect::connection();
        $stmt = $conn->prepare("DELETE FROM role WHERE role_id = ?");
        $stmt->bind_param("i", $id);
        $result = $stmt->execute();
        return $result;
    }


}