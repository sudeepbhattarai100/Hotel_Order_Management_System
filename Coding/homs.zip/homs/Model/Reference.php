<?php

date_default_timezone_set("Asia/Kathmandu");

session_start();

include_once ("DbConnect.php");
include_once ("File.php");
include_once ("Role.php");
include_once("User.php");
include_once ("Category.php");
include_once ("HotelTable.php");
include_once ("Food.php");
include_once ("Order.php");
include_once ("Sales.php");

