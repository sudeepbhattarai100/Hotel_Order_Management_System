<?php


include_once("../Model/Reference.php");

if(!isset($_SESSION["homs_user_id"])){
    header("Location: login.php");
    exit();
}

include_once ("layout/header.php");
include_once ("layout/nav.php");
include_once ("layout/notification.php");

$TableNumber = Order::GetTableDetailsOfActiveOrder();

?>

<section class="container-fluid center">
    <div class="row d-flex justify-content-around">
        <div class="col-md-2 bg-dark">
            <?php include_once ("layout/sidebar.php"); ?>
        </div>
        <div class="col-md-10 py-3">
            <h3 class="text-center text-info">Order Section</h3>

            <div class="row my-3">
                <div class="col-md-12 table-responsive mx-auto">

                    <table class="table table-stripped table-hover table-bordered">
                        <thead class="thead-dark">
                        <tr>
                            <th>S.N</th>
                            <th>Table Number</th>
                            <th colspan="3">Purchases</th>
                            <th>Current Status</th>
                            <th>Update Order Status</th>

                        </tr>
                        </thead>
                        <tbody>

                        <?php if( count($TableNumber) > 0){
                            $i = 1;
                            foreach($TableNumber as $t){
                                $tableOrders = Order::GetOrderByTable($t["table_id"]);
                                $purchases = "";
                                $current_status = "";
                                $update_status = "";
                                foreach ($tableOrders as $to){

                                    $purchases .= "<img src='../images/". $to['image']."' alt='' style='height: 60px; width: 60px' class='rounded-circle'>";
                                    $purchases .= $to["category"] ." - ". $to["food_name"] ." [ ".$to["quantity"]." (Plate) ]";
                                    $purchases .= "</br>";

                                    $current_status .= $to["order_status"]."</br>";

                                    $update_status .= "<a href='../Controller/OrderController.php?order_status_cooking=".$to["order_id"]."' class='btn btn-danger btn-sm'>Cooking</a>";
                                    $update_status .= "<a href='../Controller/OrderController.php?order_status_served=".$to["order_id"]."' class='btn btn-warning btn-sm mx-2'>Served</a>";
                                    $update_status .= "<a href='../Controller/OrderController.php?order_status_dispatched=".$to["order_id"]."' class='btn btn-success btn-sm'>Dispatched</a></br>";
                                }

                                ?>

                                <tr style="line-height: 60px">
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo $t["table_number"]; ?></td>
                                    <td colspan="3"><?php echo $purchases; ?></td>
                                    <td><?php echo strtoupper($current_status); ?></td>
                                   <td><?php echo $update_status; ?></td>
                                </tr>

                                <?php $i++; }  }else{ ?>
                            <tr class="text-center text-danger"><td colspan="6">No Orders Yet</td></tr>

                        <?php } ?>
                        </tbody>
                    </table>

                </div>

            </div>
        </div>
    </div>
</section>

<?php include_once ("layout/footer.php"); ?>
