<?php

include_once("../Model/Reference.php");

if(!isset($_SESSION["homs_user_id"])){
    header("Location: login.php");
    exit();
}

if(!isset($_GET["edit_food"])){
    header("Location: food.php");

}

include_once ("layout/header.php");
include_once ("layout/nav.php");
include_once ("layout/notification.php");

$food = Food::GetFoodById($_GET["edit_food"]);
$categories = Category::GetAllCategory();

?>

    <section class="container-fluid center">
        <div class="row d-flex justify-content-around">
            <div class="col-md-2 bg-dark">
                <?php include_once ("layout/sidebar.php"); ?>
            </div>
            <div class="col-md-10">
                <h3 class="text-center text-info my-3">Edit Food: <?php echo $food["food_name"]; ?></h3>

                <div class="row d-flex justify-content-center">

                    <div class="col-md-2">
                        <img src="../images/<?php echo $food["image"]; ?>" alt="" style="height: 150px; width: 150px" class="rounded-circle">
                    </div>
                    <div class="col-md-4">
                        <form action="../Controller/FoodController.php" method="post" enctype="multipart/form-data" class="p-3 border rounded border-success">
                            <input type="hidden" name="food_id" value="<?php echo $food["food_id"]; ?>">
                            <div class="form-group">
                                <label for="product_name">Food Name</label>
                                <input class="form-control" name="food_name" type="text" value="<?php echo $food["food_name"]; ?>">
                            </div>

                            <div class="form-group">
                                <label for="minimum_qty">Price</label>
                                <input class="form-control" name="price" type="number" value="<?php echo $food["price"]; ?>">
                            </div>

                            <div class="form-group">
                                <label for="category">Category</label>
                                <select name="category_id" class="form-control">
                                    <option value="0" disabled selected>Select Category</option>
                                    <?php foreach ($categories as $c){ ?>
                                        <option value="<?php echo $c["category_id"]; ?>"  <?php echo ($c["category_id"] == $food["category_id"])? "selected":""; ?> ><?php echo $c["category"]; ?></option>

                                    <?php } ?>
                                </select>

                            </div>

                            <div class="form-group">
                                <label for="image">Food Image</label>
                                <input class="form-control" name="image" type="file">
                            </div>

                            <div class="form-group">
                                <input type="submit" name="update_food" value="Update Food" class="btn btn-success d-flex ml-auto">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php include_once ("layout/footer.php"); ?>