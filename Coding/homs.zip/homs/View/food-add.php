<?php

include_once("../Model/Reference.php");

if(!isset($_SESSION["homs_user_id"])){
    header("Location: login.php");
    exit();
}

include_once ("layout/header.php");
include_once ("layout/nav.php");
include_once ("layout/notification.php");

$categories = Category::GetAllCategory();

?>

    <section class="container-fluid center">
        <div class="row d-flex justify-content-around">
            <div class="col-md-2 bg-dark">
                <?php include_once ("layout/sidebar.php"); ?>
            </div>
            <div class="col-md-10 py-3">
                <h3 class="text-center text-info">Add Food Section</h3>

                <div class="row">
                    <div class="col-md-4 mx-auto">
                        <form action="../Controller/FoodController.php" method="post" enctype="multipart/form-data" class="p-3 border rounded border-success">
                            <div class="form-group">
                                <label for="product_name">Food Name</label>
                                <input class="form-control" name="food_name" type="text" placeholder="Food Name">
                            </div>

                            <div class="form-group">
                                <label for="minimum_qty">Price</label>
                                <input class="form-control" name="price" type="number" placeholder="Price of the food">
                            </div>

                            <div class="form-group">
                                <label for="category">Category</label>
                                <select name="category_id" class="form-control">
                                    <option value="0" disabled selected>Select Category</option>
                                    <?php foreach ($categories as $c){ ?>
                                        <option value="<?php echo $c["category_id"]; ?>"><?php echo $c["category"]; ?></option>

                                    <?php } ?>
                                </select>

                            </div>

                            <div class="form-group">
                                <label for="image">Food Image</label>
                                <input class="form-control" name="image" type="file">
                            </div>

                            <div class="form-group">
                                <input type="submit" name="add_food" value="Add Food" class="btn btn-success d-flex ml-auto">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php include_once ("layout/footer.php"); ?>