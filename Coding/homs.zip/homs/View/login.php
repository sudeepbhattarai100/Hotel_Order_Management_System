
<?php
include_once("../Model/Reference.php");
include_once ("layout/header.php");
include_once ("layout/nav.php");
include_once ("layout/notification.php");

if(isset($_SESSION["homs_user_id"])){
    header("Location: index.php");
}

?>

<section class="container-fluid">
    <div class="row mt-5">
        <div class="col-md-12"><a href="table-order-view.php" class="btn btn-info d-block float-right">View Table Order</a></div>
    </div>
    <div class="row d-flex justify-content-around">
        <div class="col-md-3 mx-auto my-5 border border-info rounded p-3 bg-light">
            <h4 class="text-center text-info my-4">Login</h4>
            <form action="../Controller/LoginController.php" method="post">
                <div class="form-group">
                    <input type="text" name="email" class="form-control" placeholder="Username">
                </div>

                <div class="form-group">
                    <input type="password" name="password" placeholder="Password" class="form-control">
                </div>

                <div class="form-group">
                    <input type="submit" name="login" value="Login" class="btn btn-success btn-block">
                </div>
            </form>
        </div>
    </div>
</section>

<?php include_once ("layout/footer.php"); ?>