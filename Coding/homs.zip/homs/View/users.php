<?php

include_once("../Model/Reference.php");

if(!isset($_SESSION["homs_user_id"])){
    header("Location: login.php");
    exit();
}

include_once ("layout/header.php");
include_once ("layout/nav.php");
include_once ("layout/notification.php");

$users = User::getAllUsers();

?>

    <section class="container-fluid center">
        <div class="row d-flex justify-content-around">
            <div class="col-md-2 bg-dark">
                <?php include_once ("layout/sidebar.php"); ?>
            </div>
            <div class="col-md-10 py-3">
                <h3 class="text-center text-info">Users Section</h3>

                <div class="row my-3">
                    <div class="col-md-3 mx-auto">
                        <form action="../Controller/UserController.php" method="post" class="form-inline">
                            <div class="form-group">
                                <div class="col- mr-3">
                                    <input class="form-control" name="email" type="email" placeholder="User eamil address">
                                </div>
                                <div class="col-">
                                    <input type="submit" name="add_user" value="Add User" class="btn btn-success d-flex ml-auto">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12 mx-auto table-responsive">

                        <table class="table table-stripped table-hover border rounded border-info">
                            <thead class="thead-dark">
                                <tr>
                                    <th>S.N</th>
                                    <th>Image</th>
                                    <th>Full Name</th>
                                    <th>Email</th>
                                    <th>Address</th>
                                    <th>Phone</th>
                                    <th>Role</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($users) > 0 ){ $i = 1; foreach ($users as $u){ ?>

                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><img src="../images/<?php echo $u["image"]; ?>" alt="User profile pic" style="height: 40px; width: 40px" class="rounded-circle"></td>
                                    <td><?php echo $u["full_name"]; ?></td>
                                    <td><?php echo $u["email"]; ?></td>
                                    <td><?php echo $u["address"]; ?></td>
                                    <td><?php echo $u["phone"]; ?></td>
                                    <td><?php echo $u["role"]; ?></td>
                                    <td><a href="../Controller/UserController.php?delete_user=<?php echo $u["user_id"]; ?>" class="btn btn-sm btn-danger"><i class="fas fa-trash-alt"></i></a></td>
                                </tr>

                                <?php $i++; } }else {?>
                                    <tr><td class="text-danger text-center" colspan="7">No Users Found</td></tr>
                                <?php } ?>
                            </tbody>
                        </table>

                    </div>

                </div>
            </div>
        </div>
    </section>

<?php include_once ("layout/footer.php"); ?>