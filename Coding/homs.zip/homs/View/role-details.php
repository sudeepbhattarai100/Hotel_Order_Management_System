<?php

include_once("../Model/Reference.php");

if(!isset($_SESSION["homs_user_id"])){
    header("Location: login.php");
    exit();
}

if(!isset($_GET["role_id"])){
    header("Location: role.php");
}

include_once ("layout/header.php");
include_once ("layout/nav.php");
include_once ("layout/notification.php");

$role = Role::GetRoleById($_GET["role_id"]);
$UserInRole = Role::GetUsersInRole($_GET["role_id"]);
$UserNotInRole = Role::GetUsersNotInRole($_GET["role_id"]);

?>

    <section class="container-fluid center">
        <div class="row d-flex justify-content-around">
            <div class="col-md-2 py-2 bg-dark">
                <?php include_once ("layout/sidebar.php"); ?>
            </div>
            <div class="col-md-10">

                <h3 class="text-info text-center">Role <?php echo $role["role"]; ?> Details</h3>

                <div class="row py-4 d-flex justify-content-around">
                    <div class="col-md-3">
                        <ul class="list-group">
                            <?php if(count($UserInRole) > 0){foreach ($UserInRole as $u){ ?>
                                <li class="list-group-item"><?php echo $u["full_name"]; ?></li>
                            <?php }}else{ ?>
                                <li class="list-group-item text-danger"><?php echo "No User Found"; ?></li>
                            <?php } ?>
                        </ul>
                    </div>

                </div>

                <div class="roe d-flex justify-content-around">
                    <div class="col-md-3">
                        <form action="../Controller/RoleController.php" method="post">
                            <input type="hidden" name="role_id" value="<?php echo $_GET["role_id"]; ?>">
                            <div class="form-group">
                                <label for="">Add User To Role <?php echo $role["role"]; ?></label>
                                <select name="user_id" id="" class="form-control">
                                    <?php if(count($UserNotInRole) > 0){ ?>
                                    <option value="0" disabled selected>Select User</option>
                                    <?php foreach ($UserNotInRole as $u){ ?>
                                        <option value="<?php echo $u["user_id"]; ?>" ><?php echo $u["full_name"];  ?></option>
                                    <?php }}else{ ?>
                                        <option class="text-danger" value="0" disabled selected>No User Found</option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <input type="submit" name="change_role" value="Add To Role" class="btn btn-success btn-block">
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </section>

<?php include_once ("layout/footer.php"); ?>