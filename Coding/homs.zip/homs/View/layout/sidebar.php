<ul class="list-group sidebar m-0">

    <?php if(User::GetUserRole($_SESSION["homs_user_id"]) == "Admin"){ ?>
    <li class="list-group-item"><a href="role.php">Role</a></li>
    <li class="list-group-item"><a href="users.php">Users</a></li>
    <li class="list-group-item"><a href="category.php">Category</a></li>
    <li class="list-group-item"><a href="table.php">Table</a></li>
    <li class="list-group-item"><a href="food.php">Food</a></li>
    <li class="list-group-item"><a href="sales.php">Sales</a></li>
    <?php } ?>


    <li class="list-group-item"><a href="order-add.php">Add Order</a></li>
    <li class="list-group-item"><a href="order-view.php">View Order</a></li>



    <?php if(User::GetUserRole($_SESSION["homs_user_id"]) == "Cook"){ ?>
    <li class="list-group-item"><a href="order-status.php">Order Status</a></li>
    <?php } ?>

</ul>