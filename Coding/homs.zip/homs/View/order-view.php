<?php


include_once("../Model/Reference.php");

if(!isset($_SESSION["homs_user_id"])){
    header("Location: login.php");
    exit();
}

include_once ("layout/header.php");
include_once ("layout/nav.php");
include_once ("layout/notification.php");

$TableNumber = Order::GetTableDetailsOfActiveOrder();

?>

<section class="container-fluid center">
    <div class="row d-flex justify-content-around">
        <div class="col-md-2 bg-dark">
            <?php include_once ("layout/sidebar.php"); ?>
        </div>
        <div class="col-md-10 py-3">
            <h3 class="text-center text-info">Order Section</h3>

            <div class="row my-3">
                <div class="col-md-12 table-responsive mx-auto">

                    <table class="table table-stripped table-hover table-bordered">
                        <thead class="thead-dark">
                        <tr>
                            <th>S.N</th>
                            <th>Table Number</th>
                            <th colspan="3">Purchases</th>
                            <th>Amount</th>
                            <th>New Order</th>

                            <?php if(User::GetUserRole($_SESSION["homs_user_id"]) == "Admin"){ ?>

                            <th>Pay</th>

                            <?php } ?>
                        </tr>
                        </thead>
                        <tbody>

                        <?php if( count($TableNumber) > 0){
                            $i = 1;
                            foreach($TableNumber as $t){
                                $tableOrders = Order::GetOrderByTable($t["table_id"]);
                                $purchases = "";
                                $total = 0;
                                foreach ($tableOrders as $to){
                                    $subtotal = $to["quantity"] * $to["price"];
                                    $purchases .= "<img src='../images/". $to['image']."' alt='' style='height: 60px; width: 60px' class='rounded-circle'>";
                                    $purchases .= $to["category"] ." - ". $to["food_name"] ." [ ".$to["quantity"]." (Plate) * Rs.". $to["price"] ." (rate) ] = Rs." . $subtotal;
                                    $purchases .= "</br>";
                                    $total +=  $subtotal;
                                }

                                ?>

                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo $t["table_number"]; ?></td>
                                    <td colspan="3"><?php echo $purchases; ?></td>
                                    <td><?php echo $total; ?></td>
                                    <td><a href="order-add.php?table_id=<?php echo $t["table_id"]; ?>"><i class="fas fa-plus-circle"></i></a></td>

                                    <?php if(User::GetUserRole($_SESSION["homs_user_id"]) == "Admin"){ ?>

                                    <td><a href="../Controller/SalesController.php?order_table_id=<?php echo $t["table_id"]; ?>"><i class="fas fa-money-check"></i></a></td>

                                    <?php } ?>
                                </tr>

                                <?php $i++; }  }else{ ?>
                            <tr class="text-center text-danger"><td colspan="6">No Orders Yet</td></tr>

                        <?php } ?>
                        </tbody>
                    </table>

                </div>

            </div>
        </div>
    </div>
</section>

<?php include_once ("layout/footer.php"); ?>
