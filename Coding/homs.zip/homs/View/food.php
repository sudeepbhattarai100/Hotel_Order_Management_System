<?php

include_once("../Model/Reference.php");

if(!isset($_SESSION["homs_user_id"])){
    header("Location: login.php");
    exit();
}

include_once ("layout/header.php");
include_once ("layout/nav.php");
include_once ("layout/notification.php");

$foods = Food::GetAllFood();

if(isset($_GET["search"])){
    $foods = Food::SearchFood($_GET["search"]);
}

?>

    <section class="container-fluid center">
        <div class="row d-flex justify-content-around">
            <div class="col-md-2 bg-dark">
                <?php include_once ("layout/sidebar.php"); ?>
            </div>
            <div class="col-md-10 py-3">
                <h3 class="text-center text-info">Product Section</h3>

                <div class="row my-3">
                    <div class="col-md-9 mx-auto">
                        <div class="row">
                            <div class="col-md-6">

                                <form method="get">
                                    <div class="form-inline">
                                        <div class="col-">
                                            <input type="text" name="search" class="form-control" placeholder="Search Food">
                                        </div>
                                        <div class="col- mx-2">
                                            <input type="submit" value="Search" class="btn btn-success">
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="col-md-6">
                                <a href="food-add.php" class="btn btn-info float-right">Add New Food</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">

                    <div class="col-md-9 mx-auto table-responsive">
                        <table class="table table-stripped table-hover table-bordered">
                            <thead class="thead-dark">
                            <tr>
                                <th>S.N</th>
                                <th>Image</th>
                                <th>Food Name</th>
                                <th>Price</th>
                                <th>Category</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                            </thead>
                            <tbody id="food_data">

                            <?php if($foods->num_rows > 0){
                                $i = 1;
                                foreach($foods as $f){
                                    ?>

                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><img src="../images/<?php echo $f["image"]; ?>" alt="" style="height: 40px; width: 40px" class="rounded-circle"></td>
                                        <td><?php echo $f["food_name"];  ?></td>
                                        <td><?php echo $f["price"];  ?></td>
                                        <td><?php echo $f["category"];  ?></td>
                                        <td><a href="food-edit.php?edit_food=<?php echo $f["food_id"]; ?>" class="btn btn-info btn-sm"><i class="fas fa-pencil-alt"></i></a></td>
                                        <td><a href="../Controller/FoodController.php?delete_food=<?php echo $f["food_id"]; ?>" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></a></td>
                                    </tr>

                                    <?php $i++; }  }else{ ?>
                                <tr class="text-center text-danger"><td colspan="8">No Food Yet</td></tr>

                            <?php } ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </section>

<?php include_once ("layout/footer.php"); ?>