<?php

include_once("../Model/Reference.php");

if(!isset($_SESSION["homs_user_id"])){
    header("Location: login.php");
    exit();
}

include_once ("layout/header.php");
include_once ("layout/nav.php");
include_once ("layout/notification.php");

$roles = Role::GetAllRoles();

?>

    <section class="container-fluid center">
        <div class="row d-flex justify-content-around">
            <div class="col-md-2 py-2 bg-dark">
                <?php include_once ("layout/sidebar.php"); ?>
            </div>
            <div class="col-md-10">

                <h3 class="text-info text-center">Roles Section</h3>

                <div class="row py-4 d-flex justify-content-around">
                    <div class="col-md-10 table-responsive">
                        <h5 class="text-center text-info">Roles Available</h5>
                        <table class="table table-hover table-stripped table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>S.N</th>
                                    <th>Role</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>

                            <?php $i=1; foreach ($roles as $r){ ?>

                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo $r["role"] ?></td>
                                    <td><a href="role-details.php?role_id=<?php echo $r["role_id"]; ?>" class="btn btn-info btn-sm"><i class="fas fa-eye"></i></a></td>
                                </tr>

                            <?php $i++; } ?>

                            </tbody>
                        </table>
                    </div>

                </div>
            </div>

        </div>
    </section>

<?php include_once ("layout/footer.php"); ?>