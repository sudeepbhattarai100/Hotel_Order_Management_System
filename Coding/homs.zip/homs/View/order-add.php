<?php

include_once("../Model/Reference.php");

if(!isset($_SESSION["homs_user_id"])){
    header("Location: login.php");
    exit();
}

include_once ("layout/header.php");
include_once ("layout/nav.php");
include_once ("layout/notification.php");

$categories = Category::GetAllCategory();
$tables = HotelTable::GetAllTable();
$table_id = null;
if(isset($_GET["table_id"])){
    $table_id = $_GET["table_id"];
}
?>

    <section class="container-fluid center">
        <div class="row d-flex justify-content-around">
            <div class="col-md-2 bg-dark">
                <?php include_once ("layout/sidebar.php"); ?>
            </div>
            <div class="col-md-10 py-3">
                <h3 class="text-center text-info">Add Order</h3>

                <div class="row">
                    <div class="col-md-4 mx-auto">
                        <form action="../Controller/OrderController.php" method="post" enctype="multipart/form-data" class="p-3 border rounded border-success">
                            <div class="form-group">
                                <label for="category">Table Number</label>
                                <select name="table_id" class="form-control">
                                    <option value="0" disabled selected>Select Table</option>
                                    <?php foreach ($tables as $t){ ?>
                                        <option value="<?php echo $t["table_id"]; ?>" <?php echo (!empty($table_id) && $table_id == $t["table_id"])? "selected":""; ?>><?php echo $t["table_number"]; ?></option>

                                    <?php } ?>
                                </select>

                            </div>

                            <div class="form-group">
                                <label for="category">Category</label>
                                <select name="cat_id" id="category" class="form-control">
                                    <option value="0" disabled selected>Select Category</option>
                                    <?php foreach ($categories as $c){ ?>
                                        <option value="<?php echo $c["category_id"]; ?>"><?php echo $c["category"]; ?></option>

                                    <?php } ?>
                                </select>

                            </div>


                            <div class="form-group">
                                <label for="food">Food</label>
                                <select name="food_id" id="food" class="form-control" disabled>
                                    <option value="0" disabled selected>Select Food</option>
                                </select>

                            </div>


                            <div class="form-group">
                                <label for="">Quantity</label>
                                <input type="number" name="quantity" class="form-control">

                            </div>


                            <div class="form-group">
                                <input type="submit" name="add_order" value="Add Order" class="btn btn-success d-flex ml-auto">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php include_once ("layout/footer.php"); ?>