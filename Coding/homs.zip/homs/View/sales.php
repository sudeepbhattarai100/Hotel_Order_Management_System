<?php


include_once("../Model/Reference.php");

if(!isset($_SESSION["homs_user_id"])){
    header("Location: login.php");
    exit();
}



$sales = Sales::GetAllSales();
$categories = Category::GetAllCategory();

if(isset($_GET["apply_filter"])){

    $category_id = null;
    $food_id = null;

    if(isset($_GET["cat_id"])){
        $category_id = $_GET["cat_id"];

    }

    if(isset($_GET["food_id"])){
        $food_id = $_GET["food_id"];
    }
        $start_date = $_GET["start_date"];
        $end_date = $_GET["end_date"];

        if($food_id == 0){
            $food_id = null;
        }

        if(!isset($_GET["start_date"]) || empty($_GET["start_date"])){
            $start_date = date("Y-m-d");
        }

        if(!isset($_GET["end_date"]) || empty($_GET["end_date"])){
            $end_date = $start_date;
        }

        $sales = Sales::FilterSales($category_id, $food_id, $start_date, $end_date);

}

include_once ("layout/header.php");
include_once ("layout/nav.php");
include_once ("layout/notification.php");
?>

<section class="container-fluid center">
    <div class="row d-flex justify-content-around">
        <div class="col-md-2 bg-dark">
            <?php include_once ("layout/sidebar.php"); ?>
        </div>
        <div class="col-md-10 py-3">
            <h3 class="text-center text-info">Sales Section</h3>
            <div class="row mt-4">
                <div class="col-md-10 mx-auto">
                    <form method="get" class="form-inline">
                        <div class="form-group">
                            <div class="col- mr-3">
                                <label for="category">Category</label>
                                <select name="cat_id" id="category" class="form-control">
                                    <option value="0" disabled selected>Select Category</option>
                                    <?php foreach ($categories as $c){ ?>
                                        <option value="<?php echo $c["category_id"]; ?>"><?php echo $c["category"]; ?></option>

                                    <?php } ?>
                                </select>
                            </div>
                            <div class="col- mr-3">
                                <label for="food">Food</label>
                                <select name="food_id" id="food" class="form-control" disabled>
                                    <option value="0" disabled selected>Select Food</option>
                                </select>
                            </div>

                            <div class="col- mr-3">
                                <label for="food">Start Date</label>
                                <input type="date" name="start_date" class="form-control">
                            </div>


                            <div class="col- mr-3">
                                <label for="food">End Date</label>
                                <input type="date" name="end_date" class="form-control">
                            </div>

                            <div class="col- mr-3">
                                <label for="food">Filter</label>
                                <input type="submit" value="Apply" name="apply_filter" class="btn btn-success">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row my-3">
                <div class="col-md-10 table-responsive mx-auto">

                    <table class="table table-stripped table-hover table-bordered">
                        <thead class="thead-dark">
                        <tr>
                            <th>S.N</th>
                            <th>Image</th>
                            <th>Date</th>
                            <th>Category</th>
                            <th>Food Name</th>
                            <th>Quantity</th>
                            <th>Rate</th>
                            <th>Total</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php if( count($sales) > 0){
                            $i = 1;
                            $total = 0;
                            foreach($sales as $s){
                                $sub_total = $s["quantity"] * $s["price"];
                                ?>

                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><img src="../images/<?php echo $s["image"]; ?>" alt="" style="height: 50px; width: 50px" class="rounded-circle"></td>
                                    <td><?php echo $s["date"]; ?></td>
                                    <td><?php echo $s["category"]; ?></td>
                                    <td><?php echo $s["food_name"]; ?></td>
                                    <td><?php echo $s["quantity"]; ?></td>
                                    <td><?php echo "Rs. ".$s["price"]; ?></td>
                                    <td><?php echo "Rs. ".$sub_total; ?></td>
                                </tr>

                                <?php $i++; $total += $sub_total; }
                        ?>
                                <tr><td colspan="7" class="text-center text-info">Total Sales</td> <td class="text-info"><?php echo "Rs. ".$total; ?></td> </tr>
                        <?php

                        }else{ ?>
                            <tr class="text-center text-danger"><td colspan="8">No Sales Yet</td></tr>

                        <?php } ?>
                        </tbody>
                    </table>

                </div>

            </div>
        </div>
    </div>
</section>

<?php include_once ("layout/footer.php"); ?>
