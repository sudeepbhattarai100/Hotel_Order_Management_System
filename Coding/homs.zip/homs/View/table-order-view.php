<?php


include_once("../Model/Reference.php");

include_once ("layout/header.php");
include_once ("layout/nav.php");
include_once ("layout/notification.php");

$TableNumber = Order::GetTableDetailsOfActiveOrder();

if(isset($_GET["table_number"])){  }


?>

<section class="container-fluid center">
    <div class="row d-flex justify-content-around">

        <div class="col-md-10 py-3 mx-auto">
            <h3 class="text-center text-info">Your Order Status</h3>

            <div class="row my-3">
                <form action="" method="get" class="form-inline">
                    <div class="form-group">
                        <div class="col-">
                            <select name="table_number" id="" class="form-control">
                                <option value="0" disabled selected>Select Table Number</option>

                                <?php foreach ($TableNumber as $t){ ?>

                                    <option value="<?php echo $t["table_id"] ?>"><?php echo $t["table_number"] ?></option>

                                <?php } ?>
                            </select>
                        </div>
                        <div class="col- ml-3">
                            <input name="get_order" type="submit" value="Get Order" class="btn btn-success ">
                        </div>
                    </div>
                </form>
            </div>

            <div class="row my-3">
                <div class="col-md-12 table-responsive mx-auto">

                    <table class="table table-stripped table-hover table-bordered">
                        <thead class="thead-dark">
                        <tr>
                            <th>Table Number</th>
                            <th colspan="3">Order Made</th>
                            <th>Your Order Status</th>

                        </tr>
                        </thead>
                        <tbody>

                        <?php if( isset($_GET["table_number"])){
                            $i = 1;
                            foreach($TableNumber as $t){
                                $tableOrders = Order::GetOrderByTable($_GET["table_number"]);
                                $purchases = "";
                                $current_status = "";
                                foreach ($tableOrders as $to){

                                    $purchases .= "<img src='../images/". $to['image']."' alt='' style='height: 120px; width: 120px' class='rounded-circle mx-2' >";
                                    $purchases .= $to["category"] ." - ". $to["food_name"] ." [ ".$to["quantity"]." (Plate) ]";
                                    $purchases .= "</br>";

                                    $current_status .= $to["order_status"]."</br>";


                                }

                                ?>

                                <tr style="line-height: 120px; font-size: 20px">
                                    <td><?php echo $t["table_number"]; ?></td>
                                    <td colspan="3"><?php echo $purchases; ?></td>
                                    <td class="text-info font-weight-bold"><?php echo strtoupper($current_status); ?></td>

                                </tr>

                                <?php $i++; }  }else{ ?>
                            <tr class="text-center text-danger"><td colspan="5">Please select table number</td></tr>

                        <?php } ?>
                        </tbody>
                    </table>

                </div>

            </div>
        </div>
    </div>
</section>

<?php include_once ("layout/footer.php"); ?>
<script>
    $(document).ready(function(){
        setInterval (function() { location.reload(); }, 10000);
    });
</script>
