<?php


include_once("../Model/Reference.php");

if(!isset($_SESSION["homs_user_id"])){
    header("Location: login.php");
    exit();
}

include_once ("layout/header.php");
include_once ("layout/nav.php");
include_once ("layout/notification.php");

$tables = HotelTable::GetAllTable();


?>

<section class="container-fluid center">
    <div class="row d-flex justify-content-around">
        <div class="col-md-2 bg-dark">
            <?php include_once ("layout/sidebar.php"); ?>
        </div>
        <div class="col-md-10 py-3">
            <h3 class="text-center text-info">Table Section</h3>

            <div class="row my-3">
                <div class="col-md-3 mx-auto">
                    <form action="../Controller/TableController.php" method="post" class="form-inline">
                        <div class="form-group">
                            <div class="col- mr-3">
                                <input class="form-control" name="table_number" type="number" placeholder="New Table Number">
                            </div>
                            <div class="col-">
                                <input type="submit" name="add_table" value="Add Table" class="btn btn-success float-right">
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="row my-3">
                <div class="col-md-6 table-responsive mx-auto">

                    <table class="table table-stripped table-hover table-bordered">
                        <thead class="thead-dark">
                        <tr>
                            <th>S.N</th>
                            <th>Table Number</th>
                            <th>Delete</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php if( count($tables) > 0){
                            $i = 1;
                            foreach($tables as $t){
                                ?>

                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo $t["table_number"];  ?></td>
                                    <td><a href="../Controller/TableController.php?delete_table=<?php echo $t["table_id"]; ?>" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></a></td>
                                </tr>

                                <?php $i++; }  }else{ ?>
                            <tr class="text-center text-danger"><td colspan="3">No Tables Yet</td></tr>

                        <?php } ?>
                        </tbody>
                    </table>

                </div>

            </div>
        </div>
    </div>
</section>

<?php include_once ("layout/footer.php"); ?>
