<?php

include_once ("../Model/Reference.php");
$conn = DbConnect::connection();

if(isset($_POST["add_table"])){
    $table = new HotelTable();
    $table->table_number = $conn->real_escape_string($_POST["table_number"]);
    $msg = null;

    if(strlen($table->table_number <= 0)){
        $msg .= "Table number is required";
    }

    if(!empty($msg)){
        $_SESSION["error"] = $msg;
        header("Location: ../View/table.php");
        exit();
    }

    if(HotelTable::AddNewTable($table)){
        $_SESSION["success"] = "New table added successfully";
    }else{
        $_SESSION["error"] = "Unexpected error occurred while adding new table";
    }

    header("Location: ../View/table.php");
}

if(isset($_GET["delete_table"])){
    if(HotelTable::DeleteTable($_GET["delete_table"])){
        $_SESSION["success"] = "Table deleted successfully";
    }else{
        $_SESSION["error"] = "Unexpected error occurred while deleting table";
    }

    header("Location: ../View/table.php");
}
