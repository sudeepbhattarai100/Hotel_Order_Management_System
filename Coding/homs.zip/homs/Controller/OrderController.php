<?php

include_once ("../Model/Reference.php");

 if(isset($_POST["category_id"])){
    echo json_encode(Food::GetFoodByCategoryId($_POST["category_id"])) ;
 }

 if(isset($_POST["add_order"])){
     $order = new Order();
     $order->table_id = $_POST["table_id"];
     $order->food_id = $_POST["food_id"];
     $order->quantity = $_POST["quantity"];

     $msg = null;
     if(strlen($order->table_id) <= 0){ $msg .= "Please select the table.</br>"; }
     if(strlen($order->food_id) <= 0){ $msg .= "Please select the category and food.</br>"; }
     if(strlen($order->quantity) <= 0){ $msg .= "Please enter the order quantity.</br>"; }

     if(!empty($msg)){
         $_SESSION["error"] = $msg;
         header("Location: ../View/order-add.php");
         exit();
     }

     if(Order::AddOrder($order)){
         $_SESSION["success"] = "Order has been added successfully.";
     }else{
         $_SESSION["error"] = "Unknown error, please try again later.";
     }

     header("Location: ../View/order-add.php");
 }

 if(isset($_GET["order_status_cooking"])){
      $id = $_GET["order_status_cooking"];
      if(Order::UpdateOrderStatus($id, "cooking")){
          $_SESSION["success"] = "Order status is updated to cooking.";

      }else{
          $_SESSION["error"] = "Unknown error, please try again later.";
      }

     header("Location: ../View/order-status.php");
 }


 if(isset($_GET["order_status_served"])){
    $id = $_GET["order_status_served"];
    if(Order::UpdateOrderStatus($id, "served")){
        $_SESSION["success"] = "Order status is updated to served.";

    }else{
        $_SESSION["error"] = "Unknown error, please try again later.";
    }

    header("Location: ../View/order-status.php");
}


if(isset($_GET["order_status_dispatched"])){
    $id = $_GET["order_status_dispatched"];
    if(Order::UpdateOrderStatus($id, "dispatched")){
        $_SESSION["success"] = "Order status is updated to dispatched.";

    }else{
        $_SESSION["error"] = "Unknown error, please try again later.";
    }

    header("Location: ../View/order-status.php");
}