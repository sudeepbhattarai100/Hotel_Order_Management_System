
<?php

include_once ("../Model/Reference.php");

if(isset($_GET["order_table_id"])){
    $orders = Order::GetOrderDetailsByTableId($_GET["order_table_id"]);
    foreach ($orders as $o){
        $sales  = new Sales();
        $sales->table_id = $o["table_id"];
        $sales->food_id = $o["food_id"];
        $sales->quantity = $o["quantity"];
        $sales->date = date("Y-m-d");
        Sales::AddSales($sales);
    }

    if(Order::DeleteOrderByTableId($_GET["order_table_id"])){
        $_SESSION["success"] = "Payment made successfully";
    }else{
        $_SESSION["error"] = "Unknown error, please try again later.";
    }
    header("Location: ../View/order-view.php");

}