<?php

include_once ("../Model/Reference.php");

if(isset($_POST["login"])){
    if(User::validateUser($_POST["email"], md5($_POST["password"]))){
        $user = User::getUserByEmail($_POST["email"]);
        $_SESSION["success"] = "Welcome ". $user["full_name"] ." You Logged in successfully";
        $_SESSION["homs_user_id"] = $user["user_id"];
        header("Location: ../view/index.php");
    }else{
        $_SESSION["info"] = "Username or password dosen't match.";
        header("Location: ../view/login.php");
    }
}

if(isset($_POST["logout"]) && $_POST["logout"] == true){
    unset($_SESSION["homs_user_id"]);
}

