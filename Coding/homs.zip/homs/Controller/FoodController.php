
<?php

include_once ("../Model/Reference.php");
$conn = DbConnect::connection();

if(isset($_POST["add_food"])){
    $f = new Food();
    $f->food_name = $conn->real_escape_string($_POST["food_name"]);
    $f->image = "Food_".date("Ymdhis")."_".$_FILES["image"]["name"];
    $f->price = $conn->real_escape_string($_POST["price"]);
    $f->category_id = $conn->real_escape_string($_POST["category_id"]);

    $msg = null;

    if(strlen($f->food_name) < 1){$msg .= "Food name is required.</br>";}
    if(strlen($f->image) < 1){$msg .= "Image is required.</br>";}
    if(strlen($f->price) < 1){$msg .= "Price is required.</br>";}
    if(strlen($f->category_id) < 1){$msg .= "Food category is required.</br>";}
    if(!File::CheckFileType(strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION)))){$msg .= "Only JPG, JPEG and GIF image type supported.";}

    if(!empty($msg)){
        $_SESSION["error"] = $msg;
        header("Location: ../view/food-add.php");
        exit();
    }

    if(File::SaveImage($_FILES, $f->image)){
        if(Food::AddFood($f)){
            $_SESSION["success"] = "Food added successfully.";
        }else{
            $_SESSION["error"] = "Unknown error, please try again later.";
        }
    }
    header("Location: ../view/food.php");
}

if(isset($_POST["update_food"])){
    $msg = null;
    $old_details = Food::GetFoodById($_POST["food_id"]);
    $f = new Food();
    $f->food_id = $conn->real_escape_string($_POST["food_id"]);
    $f->food_name = $conn->real_escape_string($_POST["food_name"]);
    $f->price = $conn->real_escape_string($_POST["price"]);
    $f->category_id = $conn->real_escape_string($_POST["category_id"]);

    if(!empty($_FILES["image"]["name"])){
        if(!File::CheckFileType(strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION)))){$msg .= "Only JPG, JPEG and GIF image type supported.</br>";}
        $f->image = "Food_".date("Ymdhis")."_".$_FILES["image"]["name"];
    }else{
        $f->image = $old_details["image"];
    }

    if(strlen($f->food_name) < 1){$msg .= "Food name is required.</br>";}
    if(strlen($f->price) < 1){$msg .= "Price of food is required.</br>";}
    if(strlen($f->category_id) < 1){$msg .= "Food category is required.";}

    if(!empty($msg)){
        $_SESSION["error"] = $msg;
        header("Location: ../view/food-edit.php?edit_food=".$f->food_id);
        exit();
    }

    if(Food::UpdateFood($f)){
        $_SESSION["success"] = "Food updated successfully.";
        if(!empty($_FILES["image"]["name"])) {
            File::SaveImage($_FILES, $f->image);
            if(file_exists("../images/".$old_details["image"])){
                unlink("../images/".$old_details["image"]);
            }
        }
    }else{
        $_SESSION["error"] = "Unknown error, please try again later.";
    }
    header("Location: ../view/food-edit.php?edit_food=".$f->food_id);

}

if(isset($_GET["delete_food"])){
    $old_food = Food::GetFoodById($_GET["delete_food"]);
    if(Food::DeleteFood($_GET["delete_food"])){
        $_SESSION["success"] = "Food deleted successfully";
        if(file_exists("../images/".$old_details["image"])){
            unlink("../images/".$old_details["image"]);
        }
    }else{
        $_SESSION["error"] = "Unknown error, please try again later.";
    }

    header("Location: ../view/food.php");
}



$conn->close();