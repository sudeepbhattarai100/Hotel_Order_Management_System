<?php

include_once ("../Model/Reference.php");

if(isset($_POST["change_role"])){
    if(isset($_POST["user_id"])){
        if(User::AddToRole($_POST["user_id"], $_POST["role_id"])){
            $_SESSION["success"] = "User has been added to this role successfully";
        }else{
            $_SESSION["error"] = "Sorry! something went wrong";
        }
    }else{
        $_SESSION["error"] = "Please select the user to add user in this role";
    }

    header("Location: ../view/role-details.php?role_id=".$_POST["user_id"]);
}

